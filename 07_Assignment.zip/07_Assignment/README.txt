Submission Note:
Time spent: Approximately 1.5 hours

Challenges faced:
The main challenge was deciding how to structure the CSS so that each section had a distinct style while keeping the design cohesive. Another challenge was styling the navigation links and form elements to look clean and professional without overcomplicating the code.

Favorite style added:
My favorite style is the hover effect on the navigation links and submit button. It adds interactivity and a modern touch to the portfolio, making it feel more dynamic and engaging.