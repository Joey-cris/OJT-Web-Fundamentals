
let score = 85; 
let grade;
if (score >= 90) {
  grade = 'A';
} else if (score >= 80) {
  grade = 'B';
} else if (score >= 70) {
  grade = 'C';
} else if (score >= 60) {
  grade = 'D';
} else {
  grade = 'F';
}


let temperature = 25;
let weatherMessage;
if (temperature < 0) {
  weatherMessage = "It's freezing outside! Bundle up!";
} else if (temperature >= 0 && temperature <= 15) {
  weatherMessage = "It's cold outside. Wear a jacket.";
} else if (temperature >= 16 && temperature <= 30) {
  weatherMessage = "The weather is nice. Enjoy your day!";
} else {
  weatherMessage = "It's hot outside. Stay hydrated!";
}


let age = 16;
let eligibilityMessage;
if (age < 13) {
  eligibilityMessage = "You are too young for this activity.";
} else if (age >= 13 && age <= 17) {
  eligibilityMessage = "You need parental permission.";
} else {
  eligibilityMessage = "You are eligible for this activity.";
}


let ageForTicket = 15;
let isMember = true;
let ticketPrice;

if (ageForTicket < 12) {
  ticketPrice = 0; 
} else if (ageForTicket >= 12 && isMember) {
  ticketPrice = 10; 
} else if (ageForTicket >= 12 && !isMember) {
  ticketPrice = 15;
}


function isLeapYear(year) {
  if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
    return true;
  }
  return false;
}


let leapYearTest = isLeapYear(2020) ? "2020 is a leap year." : "2020 is not a leap year.";

document.getElementById("output").innerHTML = `
  <p>Grade: ${grade}</p>
  <p>Weather: ${weatherMessage}</p>
  <p>Eligibility: ${eligibilityMessage}</p>
  <p>Ticket price: $${ticketPrice}</p>
  <p>${leapYearTest}</p>
`;
