Submission Note – Portfolio Assignment

Time Spent: Approximately two hours

Reflection:
During this assignment, I focused on creating a well-structured portfolio page using semantic HTML. The main challenges included organizing multiple sections clearly, ensuring the contact form was accessible with proper <label> associations, and including a professional placeholder image. I resolved these by reviewing HTML best practices, carefully pairing labels with inputs, and generating a modern image with a descriptive alt attribute.