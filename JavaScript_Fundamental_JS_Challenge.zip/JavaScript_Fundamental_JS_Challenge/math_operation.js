
let item1 = 15;
let item2 = 20;
let item3 = 10;
let totalCost = item1 + item2 + item3;
console.log("The total cost of the items is $" + totalCost);


let num1 = 5;
let num2 = 10;
let num3 = 8;
let average = (num1 + num2 + num3) / 3;
console.log("The average is: " + average.toFixed(2));


let number = 15;
if (number % 2 === 0) {
  console.log(number + " is an even number.");
} else {
  console.log(number + " is an odd number.");
}


let originalPrice = 100;
let discountPercentage = 20;
let discountAmount = (originalPrice * discountPercentage) / 100;
let discountedPrice = originalPrice - discountAmount;
console.log("The discounted price is: $" + discountedPrice);

let finalPrice = 80;
let discount = 20;
let originalPriceBeforeDiscount = finalPrice / (1 - discount / 100);
console.log("The original price before the discount was: $" + originalPriceBeforeDiscount);
