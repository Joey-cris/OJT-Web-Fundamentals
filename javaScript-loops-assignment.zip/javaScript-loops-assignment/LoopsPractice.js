
let number = 5; 

console.log(`Multiplication Table for ${number}:`);
for (let i = 1; i <= 10; i++) {
  console.log(`${number} x ${i} = ${number * i}`);
}

let n = 5; 

let sum = 0;
for (let i = 1; i <= n; i++) {
  sum += i;
}
console.log(`The sum of the first ${n} natural numbers is: ${sum}`);
console.log(`Calculating the sum of the first ${n} numbers: 1 + 2 + 3 + 4 + 5 = ${sum}`);

let numbersArray = [2, 4, 6, 8, 10];

console.log(`The elements of the array are:`);
for (let i = 0; i < numbersArray.length; i++) {
  console.log(numbersArray[i]);
}

console.log(`Here are the elements of the array:`);
for (let i = 0; i < numbersArray.length; i++) {
  console.log(`Element ${i + 1}: ${numbersArray[i]}`);
}

console.log(`Star pattern:`);
for (let i = 1; i <= 5; i++) {
  let stars = '';
  for (let j = 1; j <= i; j++) {
    stars += '*';
  }
  console.log(stars);
}

let reverseArray = [1, 3, 5, 7, 9];

console.log(`Reversed array elements:`);
for (let i = reverseArray.length - 1; i >= 0; i--) {
  console.log(reverseArray[i]);
}

console.log(`Printing array elements in reverse order:`);
for (let i = reverseArray.length - 1; i >= 0; i--) {
  console.log(`Reversed Element ${reverseArray.length - i}: ${reverseArray[i]}`);
}
