Reflection

Time Spent: ~1.5 hours

Approach: I used Flexbox on the <main> container to align <aside> and <section> side by side, applying gap for spacing. I preserved the given widths, heights, and colors to match the example layout.

Challenges: Ensuring proper spacing and alignment without using floats or positioning.

Resolution: Flexbox allowed me to arrange elements cleanly, maintain consistent spacing, and keep the layout responsive within the fixed 1200px container.