let book = {
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    pages: 281,
    isRead: false
};

// Display book properties in HTML
document.body.innerHTML += `<p><strong>Title:</strong> ${book.title}</p>`;
document.body.innerHTML += `<p><strong>Author:</strong> ${book['author']}</p>`;

// Update and display the updated book object
book.isRead = true;
book.genre = "Fiction";
document.body.innerHTML += `<p><strong>Updated Book:</strong> Title: ${book.title}, Author: ${book.author}, Pages: ${book.pages}, Is Read: ${book.isRead}, Genre: ${book.genre}</p>`;

let movies = [
    { title: "Inception", director: "Christopher Nolan", year: 2010 },
    { title: "The Matrix", director: "The Wachowskis", year: 1999 },
    { title: "Avatar", director: "James Cameron", year: 2009 }
];

// Display title of the second movie
document.body.innerHTML += `<p><strong>Second Movie Title:</strong> ${movies[1].title}</p>`;

// Add a new movie and update the year of the first movie
movies.push({ title: "The Dark Knight", director: "Christopher Nolan", year: 2008 });
movies[0].year = 2023;
document.body.innerHTML += `<p><strong>Updated Movies:</strong></p>`;
movies.forEach(movie => {
    document.body.innerHTML += `<p>Title: ${movie.title}, Director: ${movie.director}, Year: ${movie.year}</p>`;
});

let student = {
    name: "John Doe",
    age: 18,
    subjects: ['Math', 'Science', 'History']
};

// Display the first subject
document.body.innerHTML += `<p><strong>First Subject:</strong> ${student.subjects[0]}</p>`;

// Add a new subject
student.subjects.push('English');
document.body.innerHTML += `<p><strong>Updated Student:</strong> Name: ${student.name}, Age: ${student.age}, Subjects: ${student.subjects.join(', ')}</p>`;

let recipe = {
    name: "Pasta Salad",
    ingredients: [
        { name: "Pasta", quantity: "200g", isVegetarian: true },
        { name: "Olive Oil", quantity: "3 tbsp", isVegetarian: true },
        { name: "Chicken", quantity: "100g", isVegetarian: false }
    ]
};

// Add a new ingredient and display the second ingredient
recipe.ingredients.push({ name: "Tomatoes", quantity: "2", isVegetarian: true });
document.body.innerHTML += `<p><strong>Second Ingredient:</strong> ${recipe.ingredients[1].name}</p>`;
document.body.innerHTML += `<p><strong>Updated Recipe:</strong></p>`;
recipe.ingredients.forEach(ingredient => {
    document.body.innerHTML += `<p>Ingredient: ${ingredient.name}, Quantity: ${ingredient.quantity}, Vegetarian: ${ingredient.isVegetarian}</p>`;
});
