
let book = {
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    pages: 180,
    isRead: false
};


console.log("Title: " + book.title);
console.log("Author: " + book["author"]);
console.log("Pages: " + book.pages);
console.log("Is Read: " + book.isRead);


book.isRead = true;
book.genre = "Fiction";


console.log("Updated Book Object:", book);


let movies = [
    { title: "Inception", director: "Christopher Nolan", year: 2010 },
    { title: "The Dark Knight", director: "Christopher Nolan", year: 2008 },
    { title: "Interstellar", director: "Christopher Nolan", year: 2014 }
];


console.log("Second Movie Title: " + movies[1].title);


movies.push({ title: "Dunkirk", director: "Christopher Nolan", year: 2017 });


movies[0].year = 2023;


console.log("Updated Movies Array:", movies);


let student = {
    name: "Jezreel",
    age: 20,
    subjects: ['Math', 'Science', 'History']
};


console.log("First Subject: " + student.subjects[0]);


student.subjects.push("English");


console.log("Updated Student Object:", student);


let recipe = {
    name: "Pasta Salad",
    ingredients: [
        { name: "Pasta", quantity: "2 cups", isVegetarian: true },
        { name: "Tomato", quantity: "1 cup", isVegetarian: true },
        { name: "Chicken", quantity: "200g", isVegetarian: false }
    ]
};


recipe.ingredients.push({ name: "Olives", quantity: "1/2 cup", isVegetarian: true });


console.log("Second Ingredient: " + recipe.ingredients[1].name);


console.log("Updated Recipe Object:", recipe);
