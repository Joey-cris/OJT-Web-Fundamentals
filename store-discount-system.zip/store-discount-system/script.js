
let customer_type = "member";  
let purchase_amount = 1200; 

let discount = 0;  
if (customer_type === "member") {
    if (purchase_amount >= 1000) {
        discount = 0.20;  
    } else if (purchase_amount >= 500 && purchase_amount < 1000) {
        discount = 0.10;  
        discount = 0.05;  
    }
} else if (customer_type === "non-member") {
    if (purchase_amount >= 1000) {
        discount = 0.10; 
    } else if (purchase_amount >= 500 && purchase_amount < 1000) {
        discount = 0.05;
    }
}

let final_price = purchase_amount - (purchase_amount * discount);

document.getElementById("customer-type").innerText = "Customer Type: " + customer_type;
document.getElementById("purchase-amount").innerText = "Purchase Amount: $" + purchase_amount;
document.getElementById("discount-applied").innerText = "Discount Applied: " + (discount * 100) + "%";
document.getElementById("final-price").innerText = "Final Price: $" + final_price.toFixed(2);  // Display final price with two decimals
